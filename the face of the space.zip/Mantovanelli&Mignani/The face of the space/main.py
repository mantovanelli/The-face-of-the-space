#importing the necessary libraries
from sense_hat import SenseHat
from threading import Thread
import cv2
import numpy as np
import os
import time

#necessary command to run the program
os.popen ("sudo modprobe bcm2835-v4l2")
time.sleep(1)

#setting recognition's parameters
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('/home/pi/Desktop/Astro pi/trainer.yml')

#recall the recognition library
cascadePath = "/home/pi/Desktop/Astro pi/haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);

#iniciate id counter
id = 0

# names related to ids: example ==> Oleg: id=1,  etc
name = ['None', 'christian', 'luca', 'Fra', 'Soda', 'Marco', 'Tommaso', 'Davide']
surname = ['none', 'Mantovanelli', 'Mignani', '', '']

#writing in the data file the name, data and position of ISS
f=open ("data.csv","a")
f.write("names")
f.write(",")
f.write("dates")
f.write("\n\n")
f.close()

# Initialize realtime video capture
cam = cv2.VideoCapture(0)


# Initialize all variables
id2 = 0
oleg = 0
david = 0
anne = 0
aleksey = 0
nick = 0
christina = 0
reset = 0
cc=0
j=0

# Define min window size to be recognized as a face


#start of the recognition cycle
while True:
    #increase the variable that reset the counter
    reset=reset+1
    
    ret, img =cam.read()
    
# Flip vertically
    img = cv2.flip(img, 1)

#setting of parameters
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale( 
        gray,
        scaleFactor = 1.2,
        minNeighbors = 5,
        minSize = (20,20),
       )
#if the program find a face start this for toexecute the ricognise
    for(x,y,w,h) in faces:

        sense.set_pixel(3,1, (0, 0, 0))
        sense.set_pixel(4,1, (0, 0, 0))
        sense.set_pixel(5,2, (0, 0, 0))

        

        q=[0, 0, 0]
        e=[255, 255, 50]

        truee = [
            e, e, e, q, q, e, e, e,
            e, q, q, q, q, q, q, e,
            e, q, q, q, q, q, q, e,
            q, q, q, q, q, q, q, q,
            q, q, q, q, q, q, q, q,
            e, q, q, q, q, q, q, e,
            e, q, q, q, q, q, q, e,
            e, e, e, q, q, e, e, e,
    
                             ]
        sense.set_pixels(truee)
        j=1

#switch off the last three pixel of sense hat on  
        

#associate the recognized face with an ID
        id, confidence = recognizer.predict(gray[y:y+h,x:x+w])

# Initialize all variables
        id2 = id
        classes = id

# Check if confidence is less them 100
        if (confidence < 100):
            id = name[id]
           

#account pf the times he sees a person           
            if(id2==1):
                oleg=oleg+1
            elif(id2==2):
                david=david+1
            elif(id2==3):
                anne=anne+1
            elif(id2==4):
                aleksey=aleksey+1
            elif(id2==5):
                nick=nick+1
            elif(id2==6):
                christina=christina+1
#printing o tex message                
            if(oleg+david+anne+aleksey+nick+christina==12):
                
                sense.clear(0, 0, 0)
                time.sleep(0.4)

                q=(0, 255, 53)
                e=(0, 0, 0)

                true = [
                     e, e, q, q, q, q, e, e,
                     e, q, q, q, q, q, q, e,
                     q, q, q, q, q, q, q, q,
                     q, q, q, q, q, q, q, q,
                     q, q, q, q, q, q, q, q,
                     q, q, q, q, q, q, q, q,
                     e, q, q, q, q, q, q, e,
                     e, e, q, q, q, q, e, e,
    
                     ]
                sense.low_light = True
                sense.set_pixels(true)
                time.sleep(0.3)
                sense.low_light = False
                time.sleep(1)
                sense.set_pixel(5,3, (255, 255, 255))
                time.sleep(0.1)
                sense.set_pixel(4,2, (255, 255, 255))
                time.sleep(0.1)
                sense.set_pixel(3,3, (255, 255, 255))
                time.sleep(0.1)
                sense.set_pixel(2,4, (255, 255, 255))
                time.sleep(0.1)
                sense.set_pixel(1,5, (255, 255, 255))
                time.sleep(2)
                sense.clear(0, 0, 0)
                
                sense.set_rotation(180)
                if(oleg>david and oleg>anne and oleg>aleksey and oleg>nick and oleg>christina):
                    sense.show_message(name[id2]);
                elif(david>oleg and david>anne and david>aleksey and david>nick and david>christina):
                    sense.show_message(name[id2]);
                elif(anne>oleg and anne>david and anne>aleksey and anne>nick and anne>christina):
                    sense.show_message(name[id2]);
                elif(aleksey>oleg and aleksey>david and aleksey>anne and aleksey>nick and aleksey>christina):
                    sense.show_message(name[id2]);
                elif(nick>oleg and nick>david and nick>anne and nick>aleksey and nick>christina):
                    sense.show_message(name[id2]);
                elif(christina>oleg and christina>david and christina>anne and christina>aleksey and christina>nick):
                    sense.show_message(name[id2]);
                sense.set_rotation()
                    
# Initialize all variables                    
                oleg=0
                david=0
                anne=0
                christina=0
                aleksey=0
                nick=0
                
#writing to the file csv                
                f=open ("data.csv","a")
                ts=time.strftime("%y-%m-%d %H:%M:%S")
                f.write(str(name[id2]))
                f.write(",")
                f.write(str(ts))
                f.write("\n")
                f.close()
                
            
            
#starting of thread animation
    if(j==0):
        sense.set_pixel(7,7, (0, 0, 0))
        sense.set_pixel(6,7, (0, 0, 0))
        sense.set_pixel(5,7, (0, 0, 0))
        sense.set_pixel(7,6, (0, 0, 0))
        sense.set_pixel(7,5, (0, 0, 0))
        sense.set_pixel(2,7, (0, 0, 0))
        sense.set_pixel(1,7, (0, 0, 0))
        sense.set_pixel(0,7, (0, 0, 0))
        sense.set_pixel(0,5, (0, 0, 0))
        sense.set_pixel(0,6, (0, 0, 0))
        sense.set_pixel(0,2, (0, 0, 0))
        sense.set_pixel(0,1, (0, 0, 0))
        sense.set_pixel(0,0, (0, 0, 0))
        sense.set_pixel(1,0, (0, 0, 0))
        sense.set_pixel(2,0, (0, 0, 0))
        sense.set_pixel(5,0, (0, 0, 0))
        sense.set_pixel(6,0, (0, 0, 0))
        sense.set_pixel(7,0, (0, 0, 0))
        sense.set_pixel(7,1, (0, 0, 0))
        sense.set_pixel(7,2, (0, 0, 0))
        
        if cc==0:
            thread_display=Thread(target=wait_display)
            thread_display.start()
            cc=1
        else:
            cc=cc-1
    else:
        j=0
#resetting of variables
    if(reset==100):
        oleg=0
        david=0
        anne=0
        christina=0
        aleksey=0
        nick=0
        reset=0
        
# Do a bit of cleanup
cv2.VideoCapture(0).release()
cv2.destroyAllWindows()
